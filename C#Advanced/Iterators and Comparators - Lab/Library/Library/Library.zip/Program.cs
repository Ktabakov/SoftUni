﻿using System;

namespace IteratorsAndComparators
{
     class Program
    {
        static void Main(string[] args)
        {
            Book[] books = new Book[]
                {
                    new Book("SeTaq", 1943, new string[]{"A.A. FDSFS"}),
                    new Book("Under the Dome", 2000, "Stephen King")
                };
            Library<Book> myLibrary = new Library<Book>(books);

            foreach (var item in myLibrary)
            {
                Console.WriteLine(item.Title);
            }
        }
    }
}
