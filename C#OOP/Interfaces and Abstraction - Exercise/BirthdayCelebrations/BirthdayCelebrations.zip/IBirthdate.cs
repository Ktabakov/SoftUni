﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo
{
    public interface IBirthdate
    {
        public string Birthday { get; set; }
    }
}
