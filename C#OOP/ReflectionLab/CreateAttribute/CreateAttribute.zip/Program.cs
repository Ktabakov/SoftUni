﻿using AuthorProblem;
using System;

namespace AuthorProblem
{
    [Author("koko")]
    public class StartUp
    {
        [Author("Gosho")]
        static void Main(string[] args)
        {
            
        }
    }
}
