﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    public class SoulMaster : DarkWizzard
    {
        public SoulMaster(string username, int level) 
            : base(username, level)
        {
        }
    }
}
