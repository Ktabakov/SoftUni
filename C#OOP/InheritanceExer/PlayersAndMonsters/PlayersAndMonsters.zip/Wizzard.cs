﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    public class Wizzard : Hero
    {
        public Wizzard(string username, int level) 
            : base(username, level)
        {
        }
    }
}
