﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    public class DarkWizzard : Wizzard
    {
        public DarkWizzard(string username, int level)
            : base(username, level)
        {
        }
    }
}
