﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost;Database=Theatre;User Id=sa;Password=SoftUn!2021";

    }
}
