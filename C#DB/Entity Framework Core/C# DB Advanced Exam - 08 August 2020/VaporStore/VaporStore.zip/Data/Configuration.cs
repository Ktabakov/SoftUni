﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=localhost;Database=VaporStore;User Id=sa;Password=SoftUn!2021";
		
	}
}