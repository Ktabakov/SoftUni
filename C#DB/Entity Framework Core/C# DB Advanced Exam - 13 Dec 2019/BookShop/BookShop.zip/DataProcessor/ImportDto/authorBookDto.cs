﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.DataProcessor.ImportDto
{
    public class authorBookDto
    {
        public string Id { get; set; }
    }
}
