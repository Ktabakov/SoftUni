﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost;Database=TeisterMask;User Id=sa;Password=SoftUn!2021";
    }
}
