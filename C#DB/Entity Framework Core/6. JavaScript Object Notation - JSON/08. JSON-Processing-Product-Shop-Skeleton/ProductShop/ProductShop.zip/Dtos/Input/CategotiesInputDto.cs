﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Dtos
{
    public class CategotiesInputDto
    {
        public string Name { get; set; }
    }
}
