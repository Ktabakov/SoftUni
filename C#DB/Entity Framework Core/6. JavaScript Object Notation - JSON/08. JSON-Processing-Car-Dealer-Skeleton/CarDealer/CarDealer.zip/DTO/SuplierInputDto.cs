﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO
{
    public class SuplierInputDto
    {
        public string name { get; set; }
        public bool isImporter { get; set; }
    }
}
